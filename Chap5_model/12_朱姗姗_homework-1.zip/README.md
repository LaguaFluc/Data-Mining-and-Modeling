`12_朱姗姗_homework-1.pdf`： 最后报告文件。

`mising_value_model.R`：数据代码处理文件，主要进行插值、插值分析、输出数据。

`missing_data.xls`：需要处理的缺失数据。

`complete_data.xls`：插值好的数据，完整数据。