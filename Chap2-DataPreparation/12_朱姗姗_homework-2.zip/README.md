`12_朱姗姗_homework-2.pdf`：第二节课作业最后报告。

`loan_preparation.R`进行数据准备的代码文件。

`bankloan.csv`：需要进行数据准备的文件。

`ch2_case2-2_histogram.pdf`：在进行数据预处理之前，查看数据分布，保存的直方图。

`static/loan_nvars_description.csv`：原始数据统计分布。

`static/loanNew.csv`：进行极值处理之后的数据。

`static/loanNew1.csv`：在进行极值处理之后，并进行过采样之后得到的数据，此时正负样本比例为1：2.